class Demo6
{
	public static void main(String[] args)
	{
		System.out.println("Hello");
	}
}