class Demo4 
{
	public static void main(String[] args) 
	{
		System.out.println("Program Starts from here");//after executing this statement you will get new line
		System.out.print("Good Morning evryone,");//after executing this statement no new line
		System.out.println("Welcome to Automation classes");//after executing this statement you will get new line
		System.out.println("I am Shailesh");
		System.out.print("Program Ends here");//after executing this statement no new line
	}
}