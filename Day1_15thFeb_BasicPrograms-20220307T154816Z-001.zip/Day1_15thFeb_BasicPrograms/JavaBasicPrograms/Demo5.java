class Demo5 
{
	public static void main(String[] args) 
	{
		// single line comment
		/*
		   Multiline comment
		*/

		System.out.println("Program Starts from here");
		//System.out.println("@#$%^&*(1234567890"); // as this line is commented, so it won't execute by JVM
		
		/* System.out.println("Good Morning evryone");
		System.out.println("Welcome to Automation classes"); */
		System.out.println("Program Ends here");
	}
}
