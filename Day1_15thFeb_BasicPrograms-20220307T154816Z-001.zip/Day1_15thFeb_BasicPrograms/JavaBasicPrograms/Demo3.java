class Demo3
{
	public static void main(String[] args) 
	{
		System.out.println("Program Starts from here");
		System.out.println("@#$%^&*(1234567890");
		System.out.println("Good Morning evryone");
		System.out.println("Welcome to Automation classes");
		System.out.println("Program Ends here");
	}
}
