class Demo2 
{
	public static void main(String[] args) 
	{
		System.out.println("Program Starts from here");
		System.out.println("Program Ends here");
	}
}
